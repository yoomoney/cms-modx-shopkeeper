<?php
require_once (dirname(dirname(__FILE__)) . '/yoomoneykassapayment.class.php');
class YooMoneyKassaPayment_mysql extends YooMoneyKassaPayment {}