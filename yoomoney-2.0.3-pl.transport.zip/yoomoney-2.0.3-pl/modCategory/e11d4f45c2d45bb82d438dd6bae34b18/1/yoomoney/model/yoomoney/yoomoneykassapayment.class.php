<?php
class YooMoneyKassaPayment extends xPDOSimpleObject {}