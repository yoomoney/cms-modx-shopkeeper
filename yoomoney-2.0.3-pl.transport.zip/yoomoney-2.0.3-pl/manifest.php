<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Лицензионный договор.

Любое использование Вами программы означает полное и безоговорочное принятие Вами условий лицензионного договора,
размещенного по адресу https://yoomoney.ru/doc.xml?id=527132 (далее – «Лицензионный договор»). Если Вы не
принимаете условия Лицензионного договора в полном объёме, Вы не имеете права использовать программу в
каких-либо целях.',
    'readme' => '--------------------
Extra: YooMoney
--------------------
Version: 2.0

Инструкция для работы с модулем.

После установки модуля необходимо:
1. В чанке формы заказа, в списке способов оплаты указать [[!YooMoney?&action=`showMethods`]]
Т.е., например, в чанке shopOrderForm будет:
```
<select name="payment" style="width:200px;">
	<option value="При получении" [[!+fi.payment:FormItIsSelected=`При получении`]]>При получении</option>
        [[!YooMoney? &action=`showMethods` ]]
</select>
```
2. В чанке страницы заказа, в список хуков FormIt добавить YooMoneyHook
Т.е., например, чанк orderform_page
```
[[!FormIt?
&hooks=`spam,shk_fihook,YooMoneyHook,email,FormItAutoResponder,redirect`
&submitVar=`order`
&emailTpl=`shopOrderReport`
&fiarTpl=`shopOrderReport`
&emailSubject=`В интернет-магазине "[[++site_name]]" сделан новый заказ`
&fiarSubject=`Вы сделали заказ в интернет-магазине "[[++site_name]]"`
&emailTo=`[[++emailsender]]`
&redirectTo=`25`
&validate=`address:required,fullname:required,email:email:required,phone:required`
&errTpl=`<br /><span class="error">[[+error]]</span>`
]]
```
3. Создать 2 страницы: для успешно завершенного платежа и неуспешно завершенного. Указать их ID документа в параметрах сниппета YooMoney.

4. Указать настройки магазина в параметрах сниппета YooMoney.
',
    'changelog' => 'Changelog file for YooMoney component.

YooMoney 2.0.3
====================================

### v2.0.3 от 14.02.2022
* Отключен способ оплаты Webmoney
* Замена Сбербанк Онлайн на SberPay
* Обновлен SDK до версии 2.2.6

### v2.0.2 от 02.12.2021
* Обновлен SDK до версии 2.2.2

### v2.0.1 от 19.08.2021
* Исправление ссылки на демо-магазин в readme

### v2.0.0 от 10.12.2020
* Ребрендинг модуля
',
    'setup-options' => 'yoomoney-2.0.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'da2a09bf58413a43ea1a0afe5ed2d08c',
      'native_key' => 'yoomoney',
      'filename' => 'modNamespace/ff3560984dded08d45cfd6920b694862.vehicle',
      'namespace' => 'yoomoney',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '67e7e49185a2cab0377f16b51c89aa17',
      'native_key' => 1,
      'filename' => 'modCategory/e11d4f45c2d45bb82d438dd6bae34b18.vehicle',
      'namespace' => 'yoomoney',
    ),
  ),
);