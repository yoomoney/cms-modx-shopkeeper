<?php
class YandexMoneyKassaPayment extends xPDOSimpleObject {}