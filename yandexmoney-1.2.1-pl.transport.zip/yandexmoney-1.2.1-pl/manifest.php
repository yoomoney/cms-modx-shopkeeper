<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Лицензионный договор.

Любое использование Вами программы означает полное и безоговорочное принятие Вами условий лицензионного договора,
размещенного по адресу https://money.yandex.ru/doc.xml?id=527132 (далее – «Лицензионный договор»). Если Вы не
принимаете условия Лицензионного договора в полном объёме, Вы не имеете права использовать программу в
каких-либо целях.',
    'readme' => '--------------------
Extra: YandexMoney
--------------------
Version: 2.0

Инструкция для работы с модулем.

После установки модуля необходимо:
1. В чанке формы заказа, в списке способов оплаты указать [[!YandexMoney?&action=`showMethods`]]
Т.е., например, в чанке shopOrderForm будет:
```
<select name="payment" style="width:200px;">
	<option value="При получении" [[!+fi.payment:FormItIsSelected=`При получении`]]>При получении</option>
        [[!YandexMoney? &action=`showMethods` ]]
</select>
```
2. В чанке страницы заказа, в список хуков FormIt добавить YandexMoneyHook
Т.е., например, чанк orderform_page
```
[[!FormIt?
&hooks=`spam,shk_fihook,YandexMoneyHook,email,FormItAutoResponder,redirect`
&submitVar=`order`
&emailTpl=`shopOrderReport`
&fiarTpl=`shopOrderReport`
&emailSubject=`В интернет-магазине "[[++site_name]]" сделан новый заказ`
&fiarSubject=`Вы сделали заказ в интернет-магазине "[[++site_name]]"`
&emailTo=`[[++emailsender]]`
&redirectTo=`25`
&validate=`address:required,fullname:required,email:email:required,phone:required`
&errTpl=`<br /><span class="error">[[+error]]</span>`
]]
```
3. Создать 2 страницы: для успешно завершенного платежа и неуспешно завершенного. Указать их ID документа в параметрах сниппета YandexMoney.

4. Указать настройки магазина в параметрах сниппета YandexMoney.
',
    'changelog' => 'Changelog file for YandexMoney component.
 
YandexMoney 2.0.0
====================================

### v1.2.1 от 30.07.2020
* Мелкие правки

### v1.2.0 от 10.07.2020
* Обновлен SDK до версии 1.6.4

### v1.1.0 от 09.03.2019
* Добавлена поддержка отправки второго чека
* Добавлены параметры ФФД 1.05

### v1.0.4 от 09.03.2019
* Изменен лейбл для ставки НДС с 18% на 20%
* Обновлена версия SDK до 1.1.9
* Обновлен файл сборки

### v1.0.3 от 09.03.2019
* Добавлен метод ТКС.

### v1.0.2 от 05.06.2018
* Добавлена отправка описания платежа в ЛК Яндекс.Кассы

### v1.0.1 от 03.05.2018
* Актуализация PHP SDK до версии 1.0.9
* Добавлен метод "Заплатить по частям"

### v1.0.0 от 20.04.2018
* Добавлена возможность оплаты с помощью PHP SDK через API Яндекс.Кассы

',
    'setup-options' => 'yandexmoney-1.2.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '75f3d765353370d70126650d7aad8b8e',
      'native_key' => 'yandexmoney',
      'filename' => 'modNamespace/763e7743ae76553576c726d1fc4dc20e.vehicle',
      'namespace' => 'yandexmoney',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '09c6ee8677622383b3a7fead9fc885a9',
      'native_key' => 1,
      'filename' => 'modCategory/ddf8124fa09420733abac2ebb1c3d3e2.vehicle',
      'namespace' => 'yandexmoney',
    ),
  ),
);