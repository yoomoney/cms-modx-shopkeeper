<?php
require_once (dirname(dirname(__FILE__)) . '/yandexmoneykassapayment.class.php');
class YandexMoneyKassaPayment_mysql extends YandexMoneyKassaPayment {}